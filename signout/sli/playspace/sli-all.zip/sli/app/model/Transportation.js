Ext.define('Signout.model.Transportation', {
    extend: 'Ext.data.Model',

    fields: [
        'id',
        'type'
    ]

});

