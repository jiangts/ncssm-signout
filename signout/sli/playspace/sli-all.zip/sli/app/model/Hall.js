Ext.define('Signout.model.Hall', {
    extend: 'Ext.data.Model',

    fields: [
        'id',
        'name',
        'gender'
    ]

});

