Ext.define('Signout.store.SliInfos', {
    extend: 'Ext.data.Store',
    model: 'Signout.model.SliInfo'
    
//    autoLoad: true,
//    in trees
});
