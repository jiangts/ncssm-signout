Ext.define('Signout.store.MyStudents', {
    extend: 'Ext.data.Store',
    storeId: 'mystudentsstore',
    model: 'Signout.model.MyStudent'
    
//    autoLoad: true,
//    in trees
});
