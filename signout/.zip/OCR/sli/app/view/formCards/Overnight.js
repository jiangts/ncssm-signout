Ext.define('Signout.view.formCards.Overnight', {
    extend: 'Ext.panel.Panel',
    xtype: 'overnightcard',
    /*
    requires: [
        'Signout.view.forms.Daylight'
    ],
    */
    margins: '0',
    autoScroll: true,
    border: false,

    layout: {
        type : 'hbox',
        //align: 'middle',
        pack : 'center'
    },
    items:[
        /*
        {
            xtype: 'daylight',
            margin: '30'
        }
        */
    ]
});
