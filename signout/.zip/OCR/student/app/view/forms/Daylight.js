Ext.define('Signout.view.forms.Daylight', {
    extend: 'Ext.form.Panel',
    xtype: 'daylight',

//    frame: true,
//    title: 'Daylight Hours',
    headerPosition: 'left',
    plugins: {
        ptype: 'datatip'
    },

    layout: 'form',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 85
    },
    defaultType: 'textfield',

    bodyPadding: '15',

    autoScroll: 'true',

    items: [{
        fieldLabel: 'Destination',
        afterLabelTextTpl: required,
        name: 'destination',
        allowBlank: false,
        tooltip: 'Enter Destination'
    },{
        xtype: 'combobox',
        displayField: 'type',
        store: transportation,
        typeAhead: true,
        forceSelection: true,
        //TODO gotta make queryMode local to do good form autocompletion I think :P
        queryMode: 'remote',
        //random.
        valueField: 'type',

        fieldLabel: 'Transportation',
        afterLabelTextTpl: required,
        name: 'transportation',
        allowBlank: false,
        tooltip: 'Enter Mode of Transportation'
    },{
        fieldLabel: 'Companions',
        afterLabelTextTpl: required,
        name: 'companions',
        allowBlank: false,
        tooltip: 'Enter Companions'
    },{
        xtype: 'timefield',
        fieldLabel: 'Return Time',
        name: 'time',
        minValue: '5:00am',
        maxValue: '6:00pm',
        tooltip: 'Enter a time',
        plugins: {
            ptype: 'datatip',
            tpl: 'Select time {date:date("G:i")}'
        },
        afterLabelTextTpl: required,
        allowBlank: false
    }],

    margins: '0 0 7',
    buttonAlign: 'center',
    buttons: [{
        text: 'Submit',
        handler: function() {
            this.up('form').getForm().isValid();
        }
    },{
        text: 'Cancel',
        handler: function() {
            this.up('form').getForm().reset();
        }
    }]
});

