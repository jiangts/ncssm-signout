Ext.define('Signout.view.components.Header', {
	extend: 'Ext.panel.Panel',
	xtype: 'appheader',

	/*
    border: 1,
    style: {borderColor:'#000000', borderStyle:'solid', borderWidth:'1px'},
    */

	frame: true,
	dock: 'top',
	//baseCls: 'app-header',
	//width: 0,
	//margins: '20',
	layout: {
		type: 'hbox',
		//align: 'middle'
	},
	items: [{
		xtype: 'component',
		id: 'app-header-title',
		html: 'NCSSM Off-Campus Record',
		flex: 1
	},{
        xtype: 'component',
        //id: , TODO marginalize, stylize (bolds, nice colors, Signed In should be Green or something
        id: 'app-header-bbar',
        html: 'Allan Jiang<br>Status: Signed In'
	}],
	bbar: [{
		// xtype: 'button', // default for Toolbars
		text: 'Button'
	},
	{
		xtype: 'splitbutton',
		text: 'Split Button'
	},
	// begin using the right-justified button container
	'->', // same as { xtype: 'tbfill' }
	{
		xtype: 'textfield',
		name: 'field1',
		emptyText: 'enter search term'
	},
	// add a vertical separator bar between toolbar items
	'-', // same as {xtype: 'tbseparator'} to create Ext.toolbar.Separator
	'text 1', // same as {xtype: 'tbtext', text: 'text1'} to create Ext.toolbar.TextItem
	{
		xtype: 'tbspacer'
	},
	// same as ' ' to create Ext.toolbar.Spacer
	'text 2', {
		xtype: 'tbspacer',
		width: 50
	},
	// add a 50px space
	'text 3',
    {
		xtype: 'button',
		text: 'Log Out',
		handler: function() {
			location.href = '../login/index.html';
			delCookie('token', 'sli');
		}
	}]
});
/*
Ext.define('Signout.view.components.Header', {
    extend: 'Ext.Container',
    xtype: 'appheader',
    id: 'app-header',

    border: 1,
        style: {borderColor:'#000000', borderStyle:'solid', borderWidth:'1px'},

    dock: 'top',
    baseCls: 'app-header',
    width: 0,
    //margins: '20',

    layout: {
        type: 'hbox',
        align: 'middle'
    },
   items: [{
       xtype: 'component',
       id: 'app-header-title',
       html: 'NCSSM Sign-Out Portal: Student View',
       flex: 1
   },{
       xtype:'button',
       text:'Log Out',
       handler: function(){
           location.href = '../login/index.html';
           delCookie('token','sli');
       }
   }]
});
*/
/*
Ext.define('KitchenSink.view.Header', {
    extend: 'Ext.Container',
    xtype: 'appHeader',
    id: 'app-header',
    height: 52,
    layout: {
        type: 'hbox',
        align: 'middle'
    },
    initComponent: function() {
        this.items = [{
            xtype: 'component',
            id: 'app-header-title',
            html: 'Ext JS Kitchen Sink',
            flex: 1
        }];

        if (!Ext.getCmp('options-toolbar')) {
            this.items.push({
                xtype: 'themeSwitcher'
            });
        }

        this.callParent();
    }
});
*/

