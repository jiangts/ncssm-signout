Ext.define('Signout.model.LoginStatus', {
    extend: 'Ext.data.Model',

    fields: [
        'token'
    ]

});
