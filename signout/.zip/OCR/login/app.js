/**
 * Signout.app
 *
 */
Ext.application({
    name: 'Signout',
    autoCreateViewport: true
});
delete Ext.tip.Tip.prototype.minWidth;
      
      if(Ext.isIE10) { 
          Ext.supports.Direct2DBug = true;
      }
