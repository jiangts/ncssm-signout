var tok = getCookie('token'); var tokobj = Ext.decode(tok);
var tokstr = tokobj.token;
var SLIlistobj;
Ext.define('Signout.store.SliStoreTwo', {
	extend : 'Ext.data.Store',
    storeId: 'sliliststoretwo',
	model : 'Signout.model.SliModel',
	//config : {
		proxy : {
			type : 'ajax',
			//type : 'memory',
			url: '/admin/users/list_slis.json',
            method: 'GET',
            params: {auth_token:tokstr},
			reader : { 
                type : 'json',
				root: 'items'
            },
            /*
			timeout : 20000,
			listeners : {
				exception : function() {
				}
			}
            */
		},
		sorters : 'last_name'
	//}
});
