Ext.define('Signout.model.SliModel', {
			extend : 'Ext.data.Model',
//			config : {
                fields: ['id', 'first_name', 'middle_name','last_name',
                        'email', 'created_at', 'updated_at', 'hall_id']
//			}
	});
