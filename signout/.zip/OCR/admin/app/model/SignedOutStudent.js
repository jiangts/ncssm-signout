Ext.define('Signout.model.SignedOutStudent', {
    extend: 'Ext.data.Model',

    fields: [
        'id',
        'name',
        'email',
        'phone'
    ]

});


